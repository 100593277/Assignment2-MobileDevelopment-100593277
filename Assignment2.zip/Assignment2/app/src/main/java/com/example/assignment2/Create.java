package com.example.assignment2;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import java.util.List;
import java.util.Locale;

public class Create extends AppCompatActivity {
    DbHelper d;
    EditText addy;
    EditText longt;
    EditText lat;

    private static int id = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_remove_modify);

        getSupportActionBar().setTitle("Add/Edit Location"); //set title

        d = new DbHelper(getApplicationContext()); //Retrieving database

        //Retrieving values/edittexts
        addy = (EditText) findViewById(R.id.addy);
        lat = (EditText) findViewById(R.id.lat);
        longt = (EditText) findViewById(R.id.longt);

        Bundle bundle = getIntent().getExtras();

        if (bundle != null) {
            addy.setText(bundle.getString("address"));
            lat.setText(bundle.getString("latitude"));
            longt.setText(bundle.getString("longitude"));
            id = bundle.getInt("Id");
        }

        //Onclick listeners
        ImageView done = findViewById(R.id.done);
        done.setOnClickListener(v -> saveNote(bundle));

        ImageView delete = findViewById(R.id.delete);
        delete.setOnClickListener(v -> delete(bundle));

    }

    public void saveNote(Bundle bundle){

        if (longt.getText().toString().equals("") || lat.getText().toString().equals("")){
            Toast.makeText(getApplicationContext(),"Must enter longitude and latitude!",Toast.LENGTH_LONG).show();
            return;
        }
        //Retrieving required values for longitude and latitude.
        Double LONG = Double.parseDouble(longt.getText().toString());
        Double LAT = Double.parseDouble(lat.getText().toString());

        //if bundle exists it means that an existing item was clicked
        if (bundle!= null){ //update if exists
            if (addy.getText().toString().equals("")){ //Gets address automatically if not provided "nickname"
                if (Geocoder.isPresent()) {
                    Geocoder geocoder = new Geocoder(this, Locale.getDefault());
                    try {
                        List<Address> ls= geocoder.getFromLocation(LAT,LONG,1); //find  address using geocoding
                        d.update(bundle.getInt("Id"), ls.get(0).getAddressLine(0), LAT.toString(), LONG.toString()); //update database
                    }
                    catch (Exception e) {
                        Toast.makeText(getApplicationContext(),"Address not discovered, please enter" +
                                " a new longitude and latitude",Toast.LENGTH_LONG).show();
                        return; //exits out of this if the addresss not found
                    }
                }
            }
            else{
                //If searched an existing address, no need to search/create
                d.update(bundle.getInt("Id"), addy.getText().toString(), LAT.toString(), LONG.toString()); //update database
            }


        }
        else { //bundle doesnt exist so this is a new location
            if (Geocoder.isPresent()) {
                Geocoder geocoder = new Geocoder(this, Locale.getDefault());
                try {
                    List<Address> ls= geocoder.getFromLocation(LAT,LONG,1); //Allows for address to b e found from geocode
                    d.addData(ls.get(0).getAddressLine(0), LAT.toString(), LONG.toString()); //Allows to add additional data
                }
                catch (Exception e) {
                    Toast.makeText(getApplicationContext(),"Address not found, enter new longitude and latitude",Toast.LENGTH_LONG).show();
                    return; //Return if invalid lat and long
                }
            }


        }


        startActivity(new Intent(getApplicationContext(), MainActivity.class)); //return to main activity
    }

    public void delete(Bundle bundle){


        if (id != 0){ //delete if id exists
            d.delete(id);
        }

        startActivity(new Intent(getApplicationContext(), MainActivity.class)); //return to main activity
    }

}